# TeamMarySy Telegram Bot

Single Cloudflare Worker Telegram bot implementation based on the supplied TeamMarySy implementation checklist and the provided Telegram UI screenshot.

## Architecture

- Cloudflare Worker `fetch()` webhook entry point
- Cloudflare Worker `scheduled()` Cron handler
- Native `fetch()` Telegram API client
- Cloudflare KV operational state
- Authentication, authorization, and rate limiting before dispatch
- Deterministic update router
- Feature-isolated handlers
- No persistent conversation history

## Screenshot-derived `/start` UX

`/start` presents:

1. 📱 Contact for Support
2. 💵 Register now
3. 🌐 Official Telegram ↗
4. 💰 Exclusive Offers
5. 📱 Download App

The URL buttons are configured with environment variables. The support action creates/reuses one open ticket per chat, sends the acknowledgement once per support request, optionally notifies an agent chat, and optionally sends a configured image URL.

## Requirements

Node.js 22+, npm, and Wrangler 4.123+.

## Local setup

```bash
npm ci
cp .dev.vars.example .dev.vars
# edit .dev.vars with real development values
npm test
npm run format:check
npm run lint
npm run dev
```

The webhook endpoint accepts `POST /` and requires the Telegram `X-Telegram-Bot-Api-Secret-Token` header.

## Cloudflare setup

Create KV namespaces:

```bash
npx wrangler kv namespace create TEAMMARYSY_STATE
npx wrangler kv namespace create TEAMMARYSY_STATE --preview
```

Put the returned IDs into `wrangler.jsonc` for the appropriate environments.

Set secrets outside Git:

```bash
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_WEBHOOK_SECRET
```

Set `OWNER_IDS`, `ADMIN_IDS`, allowed chats, feature flags, and the screenshot-derived URL values as environment configuration or deployment variables.

## Telegram webhook

After deploying, configure Telegram with its webhook API and the same secret token used by the Worker. Verify the webhook status and send a test `/start` update.

## Tests

The repository includes tests for command normalization, required source-tree files, secret hygiene, and callback naming. Add feature-specific integration tests as product requirements are finalized.

## Important implementation note: KV counters

Cloudflare KV does not provide a compare-and-swap primitive for safe atomic increments. The ID generator therefore uses a timestamp plus cryptographically random suffix instead of claiming strict sequential IDs. This avoids duplicate IDs under concurrency. If strict sequential IDs are a hard product requirement, add a Durable Object counter binding rather than pretending KV increments are atomic.

## Production deployment

The GitLab pipeline validates, tests, builds, deploys staging, runs staging smoke checks, and exposes production as a manual deployment on tags. Protect the production environment and restrict production variables to that environment. GitLab supports protected environments and deployment approvals for this purpose.

## Rollback

Cloudflare Worker versions should be retained according to the deployment policy. Roll back by promoting the last known-good Worker version through the Cloudflare deployment workflow; do not edit production secrets to compensate for an application rollback.

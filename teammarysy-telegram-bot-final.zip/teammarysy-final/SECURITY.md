# Security

- Never commit `TELEGRAM_BOT_TOKEN` or `TELEGRAM_WEBHOOK_SECRET`.
- Validate the Telegram webhook secret before parsing or dispatching an update.
- Restrict configured chats when the bot is intended for a closed group.
- Keep owner/admin IDs in deployment configuration.
- Rate-limit by user and chat.
- Do not log message bodies, bot tokens, webhook secrets, or full conversations.
- Keep support state to operational ticket metadata; do not archive the user's full conversation.
- Protect GitLab production environments and production deployment variables.
- Use a unique random webhook secret of sufficient entropy.

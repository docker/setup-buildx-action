import fs from 'node:fs';import path from 'node:path';
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const files=walk('src').filter(f=>/\.(ts|js)$/.test(f));for(const file of files){const s=fs.readFileSync(file,'utf8');if(s.split('\n').some(line=>/[ \t]+$/.test(line)))throw new Error(`Trailing whitespace: ${file}`);}console.log(`format check passed: ${files.length} source files`);

import fs from 'node:fs';import path from 'node:path';
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const files=walk('src').filter(f=>f.endsWith('.ts'));for(const file of files){const s=fs.readFileSync(file,'utf8');if(/console\.log\([^)]*(token|secret)/i.test(s))throw new Error(`Potential secret logging: ${file}`);}console.log(`lint check passed: ${files.length} TypeScript files`);

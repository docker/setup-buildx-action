import {State} from '../state/kv';
import {RateLimitError} from '../utils/errors';
export async function enforceRateLimit(state:State,key:string,limit:number,windowSeconds=60){
  const bucket=Math.floor(Date.now()/1000/windowSeconds); const kvKey=`rl:${bucket}:${key}`; const count=(await state.get<number>(kvKey))??0;
  if(count>=limit) throw new RateLimitError(); await state.put(kvKey,count+1,windowSeconds+5);
}

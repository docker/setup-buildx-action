import type {TelegramUpdate} from '../../telegram/types';import type {TelegramClient} from '../../telegram/client';import type {Config} from '../../config/config';import {State} from '../../state/kv';import {nextId} from '../../state/counters';import {getOpenTicketForChat,saveTicket} from '../../state/tickets';import {supportAcknowledgement} from '../../telegram/messages';
function message(update:TelegramUpdate){return update.message??update.edited_message??update.callback_query?.message;}
export async function supportHandler(update:TelegramUpdate,bot:TelegramClient,c:Config,state?:State){const m=message(update);if(!m)return;const s=state??undefined;if(!s){await bot.sendMessage(m.chat.id,supportAcknowledgement);return;}let ticket=await getOpenTicketForChat(s,m.chat.id);if(!ticket){ticket={id:nextId(s,'ticket'),chatId:m.chat.id,userId:m.from?.id??0,status:'open',lastActivity:Date.now(),createdAt:Date.now()};await saveTicket(s,ticket);}
  await bot.sendMessage(m.chat.id,supportAcknowledgement);
  if(c.supportAgentChatId){await bot.sendMessage(c.supportAgentChatId,`New support request ${ticket.id}\nChat: ${m.chat.id}\nUser: ${m.from?.id??'unknown'}`);}
  if(c.supportImageUrl) await bot.sendPhoto(m.chat.id,c.supportImageUrl);
}

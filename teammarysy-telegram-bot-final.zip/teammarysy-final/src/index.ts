import type {Env} from './telegram/types';import {handleWebhook} from './webhook/handler';import {handleCron} from './cron/handler';
export default {fetch(request:Request,env:Env){return handleWebhook(request,env);},scheduled(_controller:ScheduledController,env:Env,_ctx:ExecutionContext){return handleCron(env);}};

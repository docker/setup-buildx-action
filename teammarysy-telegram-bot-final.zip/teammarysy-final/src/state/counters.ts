import {State} from './kv';
// KV has no compare-and-swap primitive. We therefore use a UUID suffix to guarantee uniqueness under concurrency.
// The human-facing prefix remains predictable; callers must not rely on strict sequential ordering.
export function nextId(_state:State,name:string){const suffix=crypto.randomUUID().replaceAll('-','').slice(0,10).toUpperCase();return `${name.toUpperCase()}-${Date.now().toString(36).toUpperCase()}-${suffix}`;}

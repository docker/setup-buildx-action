import {State} from './kv';
export interface Job {id:string;runAt:number;type:'sendMessage'|'closeTicket'|'broadcast';payload:Record<string,unknown>;enabled:boolean;lockedUntil?:number;}
export async function saveJob(s:State,j:Job){await s.put(`job:${j.id}`,j);}
export async function getDueJobs(s:State,limit=50){const list=await s.list('job:',limit);const jobs:Job[]=[];for(const k of list.keys){const j=await s.get<Job>(k.name);if(j?.enabled&&j.runAt<=Date.now()&&(j.lockedUntil??0)<Date.now())jobs.push(j);}return jobs;}

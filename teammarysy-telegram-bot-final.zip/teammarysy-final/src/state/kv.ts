export class State {
  constructor(private kv:KVNamespace){}
  get<T>(key:string):Promise<T|null>{return this.kv.get<T>(key,'json');}
  put<T>(key:string,value:T,ttlSeconds?:number):Promise<void>{return this.kv.put(key,JSON.stringify(value),ttlSeconds?{expirationTtl:ttlSeconds}:undefined);}
  delete(key:string):Promise<void>{return this.kv.delete(key);}
  list(prefix:string,limit=100){return this.kv.list({prefix,limit});}
}

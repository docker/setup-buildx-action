export const supportAcknowledgement='Thank you for your patience. Your request to be connected to a live agent is important to us. Please hold on for a moment as we are working to connect you shortly 🙂';
export const unknownCommand='I did not recognize that command. Use /start to open the main menu.';
export const unauthorized='You do not have permission to use this feature.';

export class AppError extends Error {
  constructor(public code:string, public status:number, message:string) { super(message); this.name='AppError'; }
}
export class BadRequestError extends AppError { constructor(message='Bad request'){super('BAD_REQUEST',400,message);} }
export class UnauthorizedError extends AppError { constructor(message='Unauthorized'){super('UNAUTHORIZED',403,message);} }
export class RateLimitError extends AppError { constructor(message='Rate limit exceeded'){super('RATE_LIMITED',429,message);} }
export function normalizeError(error:unknown):AppError {
  if(error instanceof AppError) return error;
  if(error instanceof SyntaxError) return new BadRequestError('Malformed JSON');
  return new AppError('INTERNAL_ERROR',500,'Internal error');
}

import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const root=process.cwd();
test('required source tree exists',()=>{for(const p of ['src/index.ts','src/webhook/handler.ts','src/router/update-router.ts','src/telegram/client.ts','src/state/kv.ts','src/cron/handler.ts','.gitlab-ci.yml','wrangler.jsonc'])assert.equal(fs.existsSync(path.join(root,p)),true,p);});
test('no obvious secrets are committed',()=>{const text=fs.readFileSync(path.join(root,'.dev.vars.example'),'utf8');assert.match(text,/TELEGRAM_BOT_TOKEN=/);assert.doesNotMatch(text,/\d{8,}:[A-Za-z0-9_-]{20,}/);});
